/* ═══════════════════════════════════════════════════════
   804 AVENUE — Shared JavaScript
   ═══════════════════════════════════════════════════════ */

/* ── Theme Switcher (runs immediately before paint) ── */
(function() {
  var saved = localStorage.getItem('804-theme');
  if (saved) document.documentElement.setAttribute('data-theme', saved);
})();

(function() {
  'use strict';

  /* ── Theme Switcher UI ── */
  var themes = [
    { id: '', label: 'Electric Blue', swatch: 'blue' },
    { id: 'gold', label: 'Amber Gold', swatch: 'gold' },
    { id: 'green', label: 'Emerald', swatch: 'green' },
    { id: 'red', label: 'Ruby Red', swatch: 'red' },
    { id: 'violet', label: 'Royal Violet', swatch: 'violet' },
    { id: 'orange', label: 'Sunset Orange', swatch: 'orange' }
  ];

  var currentTheme = localStorage.getItem('804-theme') || '';

  function buildSwitcher() {
    var btn = document.createElement('button');
    btn.className = 'theme-switcher-btn';
    btn.setAttribute('aria-label', 'Change theme');
    btn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>';

    var panel = document.createElement('div');
    panel.className = 'theme-panel';
    var html = '<div class="theme-panel-title">Choose Theme</div><div class="theme-options">';
    themes.forEach(function(t) {
      var isActive = (t.id === currentTheme) ? ' active' : '';
      html += '<button class="theme-option' + isActive + '" data-theme-id="' + t.id + '">'
        + '<span class="theme-swatch theme-swatch-' + t.swatch + '"></span>'
        + '<span class="theme-label">' + t.label + '</span>'
        + '</button>';
    });
    html += '</div>';
    panel.innerHTML = html;

    document.body.appendChild(btn);
    document.body.appendChild(panel);

    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      panel.classList.toggle('open');
    });

    document.addEventListener('click', function(e) {
      if (!panel.contains(e.target) && e.target !== btn) {
        panel.classList.remove('open');
      }
    });

    panel.querySelectorAll('.theme-option').forEach(function(opt) {
      opt.addEventListener('click', function() {
        var id = this.getAttribute('data-theme-id');
        currentTheme = id;
        if (id) {
          document.documentElement.setAttribute('data-theme', id);
          localStorage.setItem('804-theme', id);
        } else {
          document.documentElement.removeAttribute('data-theme');
          localStorage.removeItem('804-theme');
        }
        panel.querySelectorAll('.theme-option').forEach(function(o) { o.classList.remove('active'); });
        this.classList.add('active');
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', buildSwitcher);
  } else {
    buildSwitcher();
  }

  var navbar = document.getElementById('navbar');
  if (navbar) {
    window.addEventListener('scroll', function() {
      navbar.classList.toggle('scrolled', window.scrollY > 60);
    }, { passive: true });
  }

  var hamburger = document.getElementById('hamburger');
  var mobileNav = document.getElementById('mobileNav');
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', function() {
      hamburger.classList.toggle('active');
      mobileNav.classList.toggle('open');
      document.body.style.overflow = mobileNav.classList.contains('open') ? 'hidden' : '';
    });
  }
  window.closeMobile = function() {
    if (hamburger) hamburger.classList.remove('active');
    if (mobileNav) mobileNav.classList.remove('open');
    document.body.style.overflow = '';
  };

  var fadeEls = document.querySelectorAll('.fade-up');
  if (fadeEls.length) {
    var obs = new IntersectionObserver(function(entries) {
      entries.forEach(function(e, i) {
        if (e.isIntersecting) {
          setTimeout(function() { e.target.classList.add('visible'); }, i * 80);
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -30px 0px' });
    fadeEls.forEach(function(el) { obs.observe(el); });
  }

  var statNums = document.querySelectorAll('[data-count]');
  if (statNums.length) {
    var counted = false;
    var sObs = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting && !counted) {
          counted = true;
          statNums.forEach(function(num) {
            var target = parseInt(num.getAttribute('data-count'), 10);
            var suffix = num.getAttribute('data-suffix') || '+';
            var cur = 0, inc = Math.ceil(target / 50);
            var t = setInterval(function() {
              cur += inc;
              if (cur >= target) { cur = target; clearInterval(t); }
              num.textContent = cur + suffix;
            }, 28);
          });
        }
      });
    }, { threshold: 0.3 });
    var sw = statNums[0] ? statNums[0].closest('section, .stats-bar') : null;
    if (sw) sObs.observe(sw);
  }

  var btt = document.getElementById('backToTop');
  if (btt) {
    window.addEventListener('scroll', function() {
      btt.classList.toggle('show', window.scrollY > 300);
    }, { passive: true });
    btt.addEventListener('click', function() {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
      var id = this.getAttribute('href');
      if (id === '#' || id.length < 2) return;
      var el = document.querySelector(id);
      if (el) {
        e.preventDefault();
        window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 80, behavior: 'smooth' });
      }
    });
  });
})();
